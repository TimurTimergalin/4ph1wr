import sqlite3

con = sqlite3.connect('content.sqlite3')
cur = con.cursor()
cur.execute(f"""INSERT INTO levels VALUES (?, ?, ?)""", (int(input()), input(), 0))
con.commit()
con.close()
from jnius import autoclass

classs = autoclass('android.media.MediaPlayer')
print(dir(classs))